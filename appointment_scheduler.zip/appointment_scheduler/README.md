```markdown
# Appointment Scheduler — Full Project (with ER Diagram & ZIP script)

## Summary
This project is a complete Appointment Scheduler web application using:
- MySQL (database.sql)
- PHP (backend endpoints)
- HTML / CSS / JavaScript (frontend)

It supports full CRUD for clients, services, and appointments.

## ER Diagram
The ER diagram below shows the three tables and relationships (clients, services, appointments).

![ER Diagram](er_diagram.svg)

- clients.id PK
- services.id PK
- appointments.id PK
- appointments.client_id FK -> clients.id (ON DELETE CASCADE)
- appointments.service_id FK -> services.id (ON DELETE RESTRICT)

## Creating a ZIP of the Project (one-command)
I included a small shell script `create_zip.sh` that zips all project files into `appointment_scheduler.zip`.

1. Save all project files into a single folder.
2. Add the files provided, including `er_diagram.svg` and this README.md.
3. Make the script executable and run it:

   ```bash
   chmod +x create_zip.sh
   ./create_zip.sh
   ```

The script will create `appointment_scheduler.zip` in the same folder.

If you're on Windows (PowerShell), you can run:

```powershell
Compress-Archive -Path * -DestinationPath appointment_scheduler.zip
```

## Files to include in the ZIP
- database.sql
- db.php
- get_clients.php, add_client.php, update_client.php, delete_client.php
- get_services.php, add_service.php, update_service.php, delete_service.php
- get_appointments.php, add_appointment.php, update_appointment.php, delete_appointment.php
- index.html
- styles.css
- app.js
- er_diagram.svg
- README.md
- create_zip.sh

## Notes
- Update `db.php` with your DB credentials before running.
- Import `database.sql` into MySQL to create schema and sample data.
- If you want, I can produce the .zip here as a Base64 string you can decode locally — tell me if you want that and I'll generate it (it may be large).
```