-- Single SQL file: creates database, tables (with relationships), and inserts sample data
-- Usage (CLI): mysql -u root < schema_full.sql
-- If you use a password: mysql -u root -p < schema_full.sql

DROP DATABASE IF EXISTS online_voting;
CREATE DATABASE online_voting CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE online_voting;

-- Ensure a clean slate when re-importing
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS votes;
DROP TABLE IF EXISTS candidates;
DROP TABLE IF EXISTS elections;
DROP TABLE IF EXISTS voters;

SET FOREIGN_KEY_CHECKS = 1;

-- Voters table
CREATE TABLE IF NOT EXISTS voters (
  voter_id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(200) NOT NULL,
  email VARCHAR(200) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Elections table
CREATE TABLE IF NOT EXISTS elections (
  election_id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  starts_at DATETIME NULL,
  ends_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Candidates table (each candidate belongs to an election)
CREATE TABLE IF NOT EXISTS candidates (
  candidate_id INT AUTO_INCREMENT PRIMARY KEY,
  election_id INT NOT NULL,
  name VARCHAR(200) NOT NULL,
  party VARCHAR(100) NULL,
  bio TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_candidates_election FOREIGN KEY (election_id)
    REFERENCES elections(election_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Votes table (links voter -> election -> candidate)
CREATE TABLE IF NOT EXISTS votes (
  vote_id INT AUTO_INCREMENT PRIMARY KEY,
  voter_id INT NOT NULL,
  election_id INT NOT NULL,
  candidate_id INT NOT NULL,
  voted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_votes_voter FOREIGN KEY (voter_id)
    REFERENCES voters(voter_id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_votes_election FOREIGN KEY (election_id)
    REFERENCES elections(election_id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_votes_candidate FOREIGN KEY (candidate_id)
    REFERENCES candidates(candidate_id) ON DELETE CASCADE ON UPDATE CASCADE,
  -- Prevent a voter from voting more than once per election
  UNIQUE KEY unique_vote_per_election (voter_id, election_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample data: voters
INSERT INTO voters (full_name, email) VALUES
('Camille Million', 'camille@example.com'),
('Juan Dela Cruz', 'juan@example.com'),
('Alyssa Reyes', 'alyssa@example.com');

-- Sample data: elections
INSERT INTO elections (title, description, starts_at, ends_at) VALUES
('Student Council Election 2026', 'Election for student council president', '2026-01-01 08:00:00', '2026-01-07 23:59:59'),
('Club President 2026', 'Club officer election', '2026-02-01 08:00:00', '2026-02-03 23:59:59');

-- Sample data: candidates
INSERT INTO candidates (election_id, name, party, bio) VALUES
(1, 'Alex Santos', 'Unity', 'Senior; outgoing VP; platform: transparency'),
(1, 'Bea Cruz', 'Progress', 'Junior; community organizer; platform: events and outreach'),
(2, 'Carlos Tan', 'Independent', 'Club member; focus on membership growth');

-- Example votes (optional)
INSERT INTO votes (voter_id, election_id, candidate_id) VALUES
(1, 1, 1), -- Camille votes for Alex in election 1
(2, 1, 2); -- Juan votes for Bea in election 1

-- End of script